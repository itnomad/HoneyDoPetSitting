Run script/honeydopetsitting_server.pl to test the application.
